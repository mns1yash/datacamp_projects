/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package javaapplication3;

/**
 *
 * @author root
 */
public class rubbish {
    
}
//lines.add(str_1);
    //str_object new_str_obj = new str_object();
    //ArrayList<String> lines = new ArrayList<String>();
    //System.out.print(currNode.data+" "+"\n");
//            char x = (char)Array.get(arrOfNodeData, 2);
//            System.out.println(x);
//            if(x=="1"){
//                System.out.println((char)Array.get(arrOfNodeData, 2)+"The file is ready to delete");
//            }
//            else{
//                System.out.println((char)Array.get(arrOfNodeData, 2)+"The file is running");
//            }
    //String[] linesArray = lines.toArray(new String[lines.size()]);
//        channel.close();
//        file_read.close();
    //                BufferedReader in = new BufferedReader(new FileReader("/root/NetBeansProjects/JavaApplication3/src/javaapplication3/Mns.txt"));
//        String str;
//        List<String> list = new ArrayList<String>();
//        while((str = in.readLine()) != null){
//            dList.addNode(str);
//
//            list.add(str);
//        }
//        String[] stringArr = list.toArray(new String[0]);
    //System.out.print(list);
    //Add nodes to the list  
//        dList.addNode(1);  
//        dList.addNode(2);  
//        dList.addNode(3);  
//        dList.addNode(4);  
//        dList.addNode(5);  
//         RandomAccessFile file_read = new RandomAccessFile("/root/NetBeansProjects/JavaApplication3/src/javaapplication3/Mns.txt", "r");
//        FileChannel channel = file_read.getChannel();
//        System.out.println("File size is: " + channel.size());
//        ByteBuffer buffer = ByteBuffer.allocate((int) channel.size());
//        channel.read(buffer);
//        buffer.flip();//Restore buffer to position 0 to read it
//        System.out.println("Reading content and printing ... ");
//        for (int i = 0; i < channel.size(); i++) {
//            dList.addNode();
//            System.out.print((char) buffer.get());
//        }
//        StringBuilder sb = new StringBuilder();
//        String strLine = "";
//        List<String> list = new ArrayList<String>();
//        try {
//             BufferedReader br = new BufferedReader(new FileReader("/root/NetBeansProjects/JavaApplication3/src/javaapplication3/Mns.txt"));
//              while (strLine != null)
//               {
//                strLine = br.readLine();
//                sb.append(strLine);
//                sb.append(System.lineSeparator());
//                strLine = br.readLine();
//                if (strLine==null)
//                   break;
//                list.add(strLine);
//            }
//         System.out.println(Arrays.toString(list.toArray()));
//             br.close();
//        } catch (FileNotFoundException e) {
//            System.err.println("File not found");
//        } catch (IOException e) {
//            System.err.println("Unable to read the file.");
//        }
//        
//        
//        
//          File f = new File("/root/NetBeansProjects/JavaApplication3/src/javaapplication3/Mns.txt");
//
//            BufferedReader b = new BufferedReader(new FileReader(f));
//
//            String readLine = "";
//
//            System.out.println("Reading file using Buffered Reader");
//
//            while ((readLine = b.readLine()) != null) {
//                System.out.println(readLine);
//       
//
//                
//            }
//
//        }
//        
//        RandomAccessFile file_read = new RandomAccessFile("/root/NetBeansProjects/JavaApplication3/src/javaapplication3/Mns.txt", "r");
//        FileChannel channel = file_read.getChannel();
//        System.out.println("File size is: " + channel.size());
//        ByteBuffer buffer = ByteBuffer.allocate((int) channel.size());
//        channel.read(buffer);
//        buffer.flip();//Restore buffer to position 0 to read it
//        System.out.println("Reading content and printing ... ");
//        for (int i = 0; i < channel.size(); i++) {
//            System.out.print((char) buffer.get());
//        }
//
//        channel.close();
//        file_read.close();
//        
//        BufferedReader in = new BufferedReader(new FileReader("/root/NetBeansProjects/JavaApplication3/src/javaapplication3/Mns.txt"));
//        String str;
//        List<String> list = new ArrayList<String>();
//        while((str = in.readLine()) != null){
//            list.add(str);
//        }
//        String[] stringArr = list.toArray(new String[0]);
//        System.out.print(list);
////        
//        BufferedReader in_1 = new BufferedReader(new FileReader("/root/NetBeansProjects/JavaApplication3/src/javaapplication3/Mns.txt"));
//        String str_1=null;
//        ArrayList<String> lines = new ArrayList<String>();
//        while((str_1 = in_1.readLine()) != null){
//            lines.add(str_1);
//        }
//        String[] linesArray = lines.toArray(new String[lines.size()]);
//        
//        System.out.print(str_1);
//        File fileName_mns = new File("/root/NetBeansProjects/JavaApplication3/src/javaapplication3");
//        File[] files_1 = fileName_mns.listFiles();//Lists all the files of directory
//        long freeSpace = fileName_mns.getFreeSpace();//gets free space of directory
//        long totalSpace = fileName_mns.getTotalSpace();
//        System.out.print(fileName_mns);
//        System.out.println("\n" + "Free Space " + freeSpace);
//        System.out.println("\n" + "totalSpace" + totalSpace);
//        long value_ninty = (totalSpace * 90) / 100;
//        System.out.println("\n" + "Ninty percent Value " + value_ninty);
//        if (freeSpace < value_ninty) {
//            System.out.print("\n" + "Free Space is Available" + "\n");
//        } else {
//        Process p;
//        String[] command = {"/bin/sh", "-c", "find /root/NetBeansProjects/mns/src/mns/MNS -newermt \"2020-02-24 12:00:00\" -not -newermt \"2020-02-26 12:00:00\""};
//        p = Runtime.getRuntime().exec(command);
//        BufferedReader br = new BufferedReader(new InputStreamReader(p.getInputStream()));
//        String s;
//        while ((s = br.readLine()) != null) {
//            System.out.println("\n" + "Files Modified betweeen 24 and 27:" + s);
//            File fileName_mns_d = new File(s);
////            File[] files_2 = fileName_mns.listFiles();//Lists all the files of directory
//            fileName_mns_d.delete();
//        }
//    }}
//        private void delete(File file) {
//        boolean success = false;
//        if (file.isDirectory()) {
//            for (File deleteMe : file.listFiles()) {
//                delete(deleteMe);
//            }
//        }
//        success = file.delete();
//        if (success) {
//            System.out.println(file.getAbsoluteFile() + "Deleted");
//        } else {
//            System.out.println(file.getAbsoluteFile() + "Deletion failed");
//        }


//import com.sun.management.OperatingSystemMXBean;
//import com.sun.management.UnixOperatingSystemMXBean;
//import java.io.File;
//import static java.nio.file.Files.find;
//import java.text.ParseException;
//import java.util.Date;
//OperatingSystemMXBean os = new UnixOperatingSystemMXBean
//Os.stat();
//p=Runtime.getRuntime().exec("find /root/NetBeansProjects/mns/src -newermt "2020-02-24 12:00:00" -not -newermt "2020-02-26 12:00:00"");
