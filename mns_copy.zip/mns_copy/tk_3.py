from tkinter import * 
import math
import numpy as np
from tkinter import messagebox 
Top = Tk() 
C= Canvas(bg="black", height=700, width=700) 

#for i in range (5):
#    points = np.random.randint(20,500,4)
#    line = C.create_line(points[0],points[1],points[2],points[3],fill='white')
#    x1= points[1]
#    x2=points[0]
#    y1=points[2]
#    y2=points[3]
#    print("value of x1 is : " ,x1)
#    print("value of x2 is : " ,x2)
#    print("value of y1 is : " ,y1)
#    print("value of y2 is : " ,y2)
#    dif_x =(x2-x1)**2
#    print(dif_x)
#    dif_y =(y2-y1)**2
#    print(dif_y)
#    a= dif_x+ dif_y
#    print(a)
#    length_line=0.0
#    length_line = math.sqrt(a)
#    print("real length: ",length_line)
#    print(length_line)
#    print(i, "th value",length_line)
#    length_line=int(length_line)

array_list = []
print(array_list)
for i in range (2):
    points_x = np.random.randint(0,300,4)
    points_y = np.random.randint(0,600,4)
    print(points_x,"--values--",points_y)
#    line = C.create_line(points_x[0],points_x[1],points_x[2],points_x[3],fill='white')
#    line= C.create_line(points_x[2],points_x[3],points_y[0],points_y[1], fill='white')
#    line= C.create_line(points_y[0],points_y[1],points_y[2],points_y[3], fill='white')
#    line= C.create_line(points_y[2],points_y[3],points_x[0],points_x[1], fill='white')
    poly = C.create_polygon(np.random.randint(0,300,4))

    
#    x1= points_x[0]
#    x2=points_x[1]
#    y1=points_y[0]
#    y2=points_y[1]
#    print("value of x1 is : " ,x1)
#    print("value of x2 is : " ,x2)
#    print("value of y1 is : " ,y1)
#    print("value of y2 is : " ,y2)
#    dif_x =(x2-x1)**2
#    print(dif_x)
#    dif_y =(y2-y1)**2
#    print(dif_y)
#    a= dif_x+ dif_y
#    print(a)
#    length_line=0.0
#    length_line = math.sqrt(a)
#    print("real length: ",length_line)
#    print(length_line)
#    print(i, "th value",length_line)
#    length_line=int(length_line)
#    array_list.append(length_line)
#    print(array_list,"new array value ")
#    print(min(array_list))
C.pack()
Top.mainloop()

