from tkinter import *
master = Tk()
canvas_width = 100
canvas_height = 100
w=Canvas(master,width = canvas_width, height = canvas_height)
#x = master.colormapwindows()

w.pack()

cities=[]
totalCites = 5
recordDistance = 0
bestEver = 0

for i in range(totalCites):
    print("hello")
    w.create_line(i,i,20+i,30+i)
    w.create_rectangle(i+20, i+50, i+80, i+70)
    mainloop()

