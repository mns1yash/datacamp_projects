package javaapplication3;

import java.io.IOException;
import java.io.BufferedReader;
import java.io.File;
import java.io.FileReader;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.logging.Level;
import java.util.logging.Logger;
import java.text.DateFormat;
import java.lang.reflect.Array;

public class NewClass {

    class Node {
        FileObj data;
        Node previous;
        Node next;

        public Node(FileObj data) {
            this.data = data;
        }
    }

        Node head, tail = null;
    public void addNode(Object data) {
        Node newNode = new Node((FileObj) data);
        if (head == null) {
            newNode.next = null;
            newNode.previous = null;
            head = tail = newNode;
        } else {
            tail.next = newNode;
            newNode.previous = tail;
            tail = newNode;
            tail.next = null;
        }
    }

    public void display() {
        Node current = head;
        if (head == null) {
            System.out.println("List is empty");
            return;
        }
        System.out.println("Nodes of doubly linked list: ");
        while (current != null) {

            System.out.print("current value"+current.data.getTime_stmp() + " ");
            current = current.next;
        }
    }

    public static void main(String[] args) throws IOException, ParseException {

        File fileName_mns = new File("/root/NetBeansProjects/JavaApplication3/src/javaapplication3");
        File[] files_1 = fileName_mns.listFiles();//Lists all the files of directory
        long freeSpace = fileName_mns.getFreeSpace();//gets free space of directory
        long totalSpace = fileName_mns.getTotalSpace();
        long value_ninty = (totalSpace * 90) / 100;
        System.out.println("\n" + "Ninty percent Value " + value_ninty);
        NewClass dList = new NewClass();
        BufferedReader in_1 = new BufferedReader(new FileReader("/root/NetBeansProjects/JavaApplication3/src/javaapplication3/Mns.txt"));
        String str_1 = null;
        while ((str_1 = in_1.readLine()) != null) {
            String[] temp = str_1.split("\t");
            boolean stats = temp[2].equalsIgnoreCase("1") ? true : false;
            String file_Name = temp[1];
            Date time_stmp = new SimpleDateFormat("YYYY-M-D hh:mm:ss").parse(temp[0]);
            dList.addNode(new FileObj(time_stmp, file_Name, stats));
            if (freeSpace < value_ninty) {
                System.out.print("\n" + "Free Space is Available" + "\n");
            } else {
                if (stats == true) {
                    System.out.println("Ready to delete");
                } else {
                    System.out.println("File " + file_Name + "The file is running");
                }
            }
        }
        Node foo = dList.head;
        //while (foo != dList.tail) {
            System.out.println("timestamp is :" + foo.data.getClass() + "\n" + "Path is :" + foo.data.getFile_Name() + "\n" + "status is :" + foo.data.isStats());
            foo = foo.next;
        //}
        System.out.println("timestamp is :" + foo.data.getClass() + "\n" + "Path is :" + foo.data.getFile_Name() + "\n" + "status is :" + foo.data.isStats());
    }

    private void delete(File file) {
        boolean success = false;
        if (file.isDirectory()) {
            for (File deleteMe : file.listFiles()) {
                delete(deleteMe);
            }
        }
        success = file.delete();
        if (success) {
            System.out.println(file.getAbsoluteFile() + "Deleted");
        } else {
            System.out.println(file.getAbsoluteFile() + "Deletion failed");
        }
    }
    //Displays the nodes present in the list  
    //System.out.print("Linked List" + "\n");
    //dList.display();
//        Node currNode = dList.head;
//        System.out.println("HeadValues" + dList.head.data);
//        while (currNode != null) {
//            System.out.println("________");
//            
//            
//            FileObj node_data = (FileObj) currNode.data;
//            if (node_data.stats == true) {
//                System.out.println("File " + node_data.file_Name + " is ready to delete");
//                System.out.println("Time Stamp of file is " + node_data.time_stmp + " is ready to delete");
//            } else {
//                System.out.println("File " + node_data.file_Name + "The file is running");
//            }
//            currNode = currNode.next;
//        }

}
//System.out.println("String of String "+string_1+"\n"+"Type"+string_1.getClass().getName());
//String tem_0;
//tem_0 = String.format((temp[0]),FileObj.stats);
//System.out.println("temo_0 testing"+tem_0+tem_0.getClass().getName());

//System.out.print("Temp length"+temp.length);
//System.out.println("Here temp2 "+temp[2]+"\n"+temp[2].getClass().getName());
//String[] arrOfStr_1 = str_1.split("\t");
//System.out.println("df" + df.getClass().getName());
//System.out.print("tem_2 value is"+tem_2);
//addNode() will add a node to the list  
//Prints each node by incrementing the pointer.  
//Node current will point to head  
//display() will print out the nodes of the list  
//As it is last node, tail's next will point to null  
//newNode will become new tail  
//newNode's previous will point to tail  
//newNode will be added after tail such that tail's next will point to newNode  
//tail's next will point to null, as it is the last node of the list  
//head's previous will point to null  
//Both head and tail will point to newNode  
//If list is empty  
        //Create a new node  
