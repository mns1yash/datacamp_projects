package javaapplication3;

import java.io.File;
import java.io.IOException;
import java.text.ParseException;
import java.util.Date;

public class fileDeleteExample {

    public static void main(String[] args) throws IOException, ParseException {
        Process p;
        File fileName_mns = new File("/root/NetBeansProjects/JavaApplication3/src/javaapplication3");
        File[] files_1 = fileName_mns.listFiles();//Lists all the files of directory
        long freeSpace = fileName_mns.getFreeSpace();//gets free space of directory
        long totalSpace = fileName_mns.getTotalSpace();
        System.out.print(fileName_mns);
        System.out.println("\n" + "Free Space " + freeSpace);
        System.out.println("\n" + "totalSpace" + totalSpace);
        long value_ninty = (totalSpace * 90) / 100;
        System.out.println("\n" + "Ninty percent Value " + value_ninty);
        if (freeSpace < value_ninty) {
            System.out.print("\n" + "Free Space is Available" + "\n");
        } else {
            System.out.println("\n" + "Filled above 90");
            for (int i = 0; i < files_1.length; i++) {
                long file_dif = new Date().getTime() - files_1[i].lastModified();
                long lastChanged_sf = file_dif / 1000;
                long lastChanged_mf = lastChanged_sf / 60;
                long lastChanged_hf = lastChanged_mf / 60;
                long lastChanged_df = lastChanged_hf / 24;
                System.out.print("\nFile Days" + lastChanged_df);
                System.out.print("\n" + "Difference " + file_dif);
                if (lastChanged_df > 1) {
                    System.out.print("i valueeeeeeeeeeeeeeeeeee" + i);
                    files_1[i].delete();
                }
            }
        }
    }

    private void delete(File file) {
        boolean success = false;
        if (file.isDirectory()) {
            for (File deleteMe : file.listFiles()) {
                delete(deleteMe);
            }
        }
        success = file.delete();
        if (success) {
            System.out.println(file.getAbsoluteFile() + "Deleted");
        } else {
            System.out.println(file.getAbsoluteFile() + "Deletion failed");
        }
    }
}

//import java.io.InputStreamReader;
//import java.text.SimpleDateFormat;
//import java.io.BufferedReader;
//import java.util.Arrays;
//import java.util.Comparator;
//        p=Runtime.getRuntime().exec("stat -c '%y' /root/NetBeansProjects/JavaApplication3/src/javaapplication3/sample/Mns.txt");
//        BufferedReader br= new BufferedReader(new InputStreamReader(p.getInputStream()));
//            String s;
//            while((s=br.readLine())!=null){
//                System.out.println("\n"+"Last Modified of FileName Mns:"+s);}
//            
//        long curr_time = System.currentTimeMillis();
//        System.out.println("\n"+"Current_Time is"+curr_time);
//        
//        Date date = new Date();
//        SimpleDateFormat dateFormat =new SimpleDateFormat("yyyy-mm-dd");
//        File folder=new File("/root/NetBeansProjects/JavaApplication3/src/javaapplication3/sample.Mns.txt");
//        System.out.println(date);
//
//        File mns_file = new File("/root/NetBeansProjects/JavaApplication3/src/javaapplication3/sample/Mns.txt"); 
//        SimpleDateFormat sdf = new SimpleDateFormat("DD/MM/yyyy HH:mm:ss");
//        System.out.println("\n"+sdf.format(mns_file.lastModified()));
//  long diff = new Date().getTime() - fileName_mns.lastModified();
//        System.out.print("\n"+"Difference "+ diff);
//                    
//            long lastChanged_s = diff/1000;
//            long lastChanged_m = lastChanged_s/60;
//            long lastChanged_h = lastChanged_m/60;
//            long lastChanged_d= lastChanged_h/24;
//System.out.print("Zero_Output"+files_1);
//        long diff_mns = new Date().getTime() - mns_file.lastModified();
//        System.out.print("\n"+"Difference_mns "+ diff_mns);
//        
//         long lastChanged_s_m = diff_mns/1000;
//            long lastChanged_m_m = lastChanged_s_m/60;
//            long lastChanged_h_m = lastChanged_m_m/60;
//            long lastChanged_d_m= lastChanged_h_m/24;
//Arrays.sort(files_1, Comparator.comparingLong(File::lastModified));
//Arrays.sort(files_1, LastModifiedFileComparator.l);
//System.out.print(p);
//new fileDeleteExample().delete(new File("/root/NetBeansProjects/JavaApplication3/src/javaapplication3/sample/Mns.txt"));}
//new fileDeleteExample().delete(new File("/root/NetBeansProjects/JavaApplication3/src/javaapplication3/sample/Mns.txt"));}
//import java.nio.file.FileSystems;
//FileSortLastModified.display.fileOrder(files_1);
//import java.util.Calendar;
//import java.nio.file.Path;
//import java.nio.file.attribute.BasicFileAttributes;
//import java.nio.file.FileSystem;
//import java.nio.file.Files;
//        String[] filesInDir = fileName_mns.list();
//        System.out.print("\n"+filesInDir);
//        Arrays.sort(filesInDir);
//        
//        for(int i=0; i<filesInDir.length;i++){
//            System.out.println("file:"+  filesInDir[i]);
//
//        
//        }
//Arrays.sort(fileName_mns, Comparator.comparingLong(File::lastModified));
//       Path start = FileSystems.getDefault().getPath("/root/NetBeansProjects/JavaApplication3/src/javaapplication3");
//       Files.walk(start).filter( path -> path.toFile().isFile()).filter( path -> path.toString().endsWith(".txt")).forEach(System.out::println);
// String fileName = "/root/NetBeansProjects/JavaApplication3/src/javaapplication3/sample/Mns.txt";
//        File myFile = new File(fileName);
//        Path path = myFile.toPath();
//        BasicFileAttributes fatr = File.readAttributes(path, BasicFileAttributes,class);
//        try{
//            p=Runtime.getRuntime().exec("stat -c '%y' /root/NetBeansProjects/JavaApplication3/src/javaapplication3/sample/Mns.txt");
//            
//            BufferedReader br= new BufferedReader(new InputStreamReader(p.getInputStream()));
//            String s;
//            while((s=br.readLine())!=null){
//                System.out.print("line:"+s);
//            }
//            p.waitFor();
//            System.out.print("Exit"+p.exitValue());
//            p.destroy();
//        }catch(IOException | InterruptedException e){}
//long lastModified = sourse.lastModified();
//System.out.print(lastModified);
//File settings = new File(".txt");
//long lastChanged = settings.lastModified();
//System.out.print(lastChanged);
//File sourse = new File(".txt");
//long lastModified = sourse.lastModified();
//System.out.print(lastModified);
//            
//            long lastChanged_s = milli_time/1000;
//            long lastChanged_m = lastChanged_s/60;
//            long lastChanged_h = lastChanged_m/60;
//            long lastChanged_d= lastChanged_h/24;
//            System.out.print("\n"+lastChanged_s);
//            System.out.print("\n"+lastChanged_m);
//            System.out.print("\n"+lastChanged_h);
//            System.out.print("\n"+lastChanged_d);
//Path foo = new Path;
//FileStore store = Files.getFileStore("");
// PrintStream println = System.out.println("available=" +nf.format(store.getUsuableSpace()) +", total=" +nf.format (Store.getTotalSpace()));
//        new fileDeleteExample().delete(new File("/root/NetBeansProjects/JavaApplication3/src/javaapplication3/sample/Mns.txt"));
//        System.out.println();
//        get = Runtime.getRunTime().Exec("df -h /root/NetBeansProjects/JavaApplication3/src/javaapplication3");
//        new fileDeleteExample().delete(new File("/root/NetBeansProjects/JavaApplication3/src/javaapplication3/sample"));
//            long lastChanged = mns_file.lastModified();
//            System.out.print("\t"+lastChanged);
//            
//            long milli_time = System.currentTimeMillis() - lastChanged;
//            System.out.print("\n"+"Milli Current "+milli_time);
//            
// Date s_date = new SimpleDateFormat ("dd-mm-yyyy").parse(s);
//  System.out.println(s_date);
//                        Date date = new Date();
//         SimpleDateFormat dateFormat = new SimpleDateFormat("YYYY-MM-DD");
//         System.out.print("\nDate Format is "+dateFormat);

