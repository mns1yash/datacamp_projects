/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package dll;

import java.io.BufferedReader;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.logging.Level;
import java.util.logging.Logger;

/**
 *
 * @author root
 */
public class DLL {

    /**
     * @param args the command line arguments
     */
    Node head; // head of list
    Node tail;
    Node temp;

    public static void main(String[] args) {
        // TODO code application logic here
        DLL dList = new DLL();

        BufferedReader in_1;
        try {
            in_1 = new BufferedReader(new FileReader("/root/NetBeansProjects/JavaApplication3/src/javaapplication3/Mns.txt"));
        
int i  =0;
        String str_1 = null;
        while ((str_1 = in_1.readLine()) != null) {

            System.out.println(str_1 + "\n" + "Hello string separator");
            String[] temp = str_1.split("\t");
            System.out.println("\n" + "Hello temp 0   " + temp[0] + "\n" + "Hello temp 1   " + temp[1] + "\n" + "Hello temp 2   " + temp[2]);

            boolean stats = temp[2].equalsIgnoreCase("1") ? true : false;
            System.out.println("Status value is : " + stats);

            String file_Name = temp[1];
            System.out.println("File Name is : " + file_Name);

            Date time_stmp = new SimpleDateFormat("YYYY-M-D hh:mm:ss").parse(temp[0]);
            System.out.println("Time Stamp is : " + time_stmp);

//            FileObj foo = new FileObj(time_stmp, file_Name, stats);
//            System.out.println("new object"+new FileObj(time_stmp, file_Name, stats));
            //dList.addNode(new Node(new FileObj(time_stmp, file_Name, stats)));
            //dList.addNode(++i);
            
        }
} catch (FileNotFoundException | ParseException ex) {
            Logger.getLogger(DLL.class.getName()).log(Level.SEVERE, null, ex);
        } catch (IOException ex) {
            Logger.getLogger(DLL.class.getName()).log(Level.SEVERE, null, ex);
        }
        System.out.println("Displays all ");
        //dList.display();
    }

    

    
}
