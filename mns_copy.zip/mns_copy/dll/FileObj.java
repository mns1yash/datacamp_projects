package dll;

import java.util.Date;

public class FileObj {
        static String file_Name;
        static Date time_stmp;
        static boolean stats;
        public FileObj(Date time_stmp, String file_Name, boolean stats){
            this.file_Name = file_Name;
            this.time_stmp = time_stmp;
            this.stats = stats;
        }

    public String getFile_Name() {
        return file_Name;
    }

    public void setFile_Name(String file_Name) {
        FileObj.file_Name = file_Name;
    }

    public Date getTime_stmp() {
        return time_stmp;
    }

    public void setTime_stmp(Date time_stmp) {
        this.time_stmp = time_stmp;
    }

    public boolean isStats() {
        return stats;
    }

    public void setStats(boolean stats) {
        FileObj.stats = stats;
    }
}
