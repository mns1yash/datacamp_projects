package dll;

import java.io.BufferedReader;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.logging.Level;
import java.util.logging.Logger;

public class Node {

    Node head;
    Node tail;
    Node temp;
    FileObj data;
    Node prev = null;
    Node next = null;

    public Node(FileObj data) {
        this.data = data;
    }

    public void addNode(FileObj new_data) {
                Node new_Node = new Node(new_data);

        if ((tail == null && head == null)) {
            head = tail = new_Node;
        } else {
            if (head == tail) {
                temp = head;
                temp.next = new_Node;
                new_Node.prev = temp;
                tail = new_Node;
            } else {
                temp = tail;
                new_Node.prev = tail;
                tail.next = new_Node;
                tail = new_Node;
            }
        }
    }

    public void display() {
        //temp = head;
        if (this.data == null) {
            System.out.println("List is empty");
            return;
        }
        System.out.println("Nodes of doubly linked list: ");
        while (head != null) {
            System.out.println("Head Previous" + head.prev);
            System.out.println("Head Value" + head);
            System.out.println("Head Next" + head.next);
            System.out.print("timestamp is :" + head.data.getTime_stmp() + "\n" + "Path is :" + head.data.getFile_Name() + "\n" + "status is :" + head.data.isStats());
            head = head.next;
            //System.out.println("tail timestamp is :" + tail.data.getTime_stmp() + "\n" + "tail Path is :" + tail.data.getFile_Name() + "\n" + "tail status is :" + tail.data.isStats());
//            System.out.print(" n timestamp is :" + temp.prev.data.getTime_stmp() + "\n" + " n Path is :" + temp.prev.data.getFile_Name() + "\n" + " n status is :" + temp.prev.data.isStats());
//             head= new Node(data);

        }
    }

    public static void main(String[] args) throws FileNotFoundException, IOException, ParseException {

        BufferedReader in_1 = new BufferedReader(new FileReader("/root/NetBeansProjects/mns_123/JavaApplication3/src/javaapplication3/Mns.txt"));
        String str_1 = null;
        while ((str_1 = in_1.readLine()) != null) {

            System.out.println(str_1 + "\n" + "Hello string separator");
            String[] temp = str_1.split("\t");
            System.out.println("\n" + "Hello temp 0   " + temp[0] + "\n" + "Hello temp 1   " + temp[1] + "\n" + "Hello temp 2   " + temp[2]);

            boolean stats = temp[2].equalsIgnoreCase("1") ? true : false;
            System.out.println("Status value is : " + stats);

            String file_Name = temp[1];
            System.out.println("File Name is : " + file_Name);

            Date time_stmp = new SimpleDateFormat("YYYY-M-D hh:mm:ss").parse(temp[0]);
            System.out.println("Time Stamp is : " + time_stmp);
//            Node node_1 = new Node(new FileObj(time_stmp, file_Name, stats));
//            node_1.display();
            FileObj foo = new FileObj(time_stmp, file_Name, stats);
            Node node_1 = new Node(foo);
            node_1.display();
//            System.out.println("new object"+new FileObj(time_stmp, file_Name, stats));
//            dList.addNode(new FileObj(time_stmp, file_Name, stats));
            
//            FileObj foo = new FileObj(time_stmp, file_Name, stats);
//            System.out.println("new object"+new FileObj(time_stmp, file_Name, stats));
//            Node.addNode(new Node(new FileObj(time_stmp, file_Name, stats)));
            //dList.addNode(++i);
        }
    }
}
