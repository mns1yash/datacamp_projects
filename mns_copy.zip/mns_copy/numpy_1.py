#import array
#arr = array.array()
#import random
#ran_r = random.Random(9)
import numpy as np
import matplotlib.pyplot as plt
a = np.empty([2,2], dtype=int)
print(a)
b = np.arange(4).reshape(2,2)
print(b)
ar = np.array([[],[]])
print(ar)
array_try_random = np.random.randint(10,30,4).reshape(2,2)
print(array_try_random)
array_list = np.array([(1,2),(3,4)])
print(array_list)
new_array = np.append(array_list, array_try_random).reshape(4,2)
points = np.arange(0, 3,1)
x, y =np.meshgrid(points,points)
z = list(map(lambda x,y : np.sqrt(x**2 + y**2),x,y ))
plt.imshow(z, cmap=plt.cm.gray)
plt.colorbar()
plt.show()
#____________________________________________________________________
items = [1, 2, 3, 4, 5]
squared = list(map(lambda x : x**2, items))
t = np.meshgrid(points,points)
print (t)
f=t[0]
g=t[1]
np.equal(x,f)
np.equal(y,g)