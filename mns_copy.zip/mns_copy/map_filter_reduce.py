items = [1, 2, 3, 4, 5]
squared = list(map(lambda x : x**2, items))
print(squared)
#___________________________________________________________________________________
number_list = range(-4,4)
less_than_zero = list(filter(lambda x : x<0 , number_list))
print(less_than_zero)
#___________________________________________________________________________________
from  functools import reduce
product=1
product = reduce((lambda x,y : x*y), items)
print(product)
#___________________________________________________________________________________
def mult(x):
    return (x*x)
def add(x):
    return(x+x)
func = [mult, add]
for i in range(5):
    value = list(map(lambda x : x(i), func))
    print(value)
#___________________________________________________________________________________
circles_area = [5.23443, 3.324, 34.34324, 24.2424]
result = list(map(round, circles_area, range(1,4)))
print(result)
#___________________________________________________________________________________
