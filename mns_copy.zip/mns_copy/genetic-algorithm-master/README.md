# genetic-algorithm
Genetic algorithm tutorial for Python

In the included notebook, we will demonstrate an end-to-end tutorial of a genetic algorithm used to solve the traveling salesman problem.

Complete overview: https://towardsdatascience.com/evolution-of-a-salesman-a-complete-genetic-algorithm-tutorial-for-python-6fe5d2b3ca35
