/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package javaapplication3;

import java.io.BufferedReader;
import java.io.File;
import java.io.IOException;
import java.io.InputStreamReader;

/**
 *
 * @author root
 */
public class NewClass2 {
        public static void main(String[] args) throws IOException {
        File fileName_mns   = new File("/root/NetBeansProjects/JavaApplication3/src/javaapplication3");
        File[] files_1 = fileName_mns.listFiles();//Lists all the files of directory
        long freeSpace = fileName_mns.getFreeSpace();//gets free space of directory
        long totalSpace = fileName_mns.getTotalSpace();
        System.out.print(fileName_mns);
        System.out.println("\n" + "Free Space " + freeSpace);
        System.out.println("\n" + "totalSpace" + totalSpace);
        long value_ninty = (totalSpace * 90) / 100; 
        System.out.println("\n" + "Ninty percent Value " + value_ninty);
        if (freeSpace < value_ninty) {
            System.out.print("\n" + "Free Space is Available" + "\n");
        } else {
        Process p;
        String[] command = {"/bin/sh", "-c", "$stat /root/NetBeansProjects/JavaApplication3/src/javaapplication3"};
        p = Runtime.getRuntime().exec(command);
        BufferedReader br = new BufferedReader(new InputStreamReader(p.getInputStream()));
        String s;
        while ((s = br.readLine()) != null) {
            System.out.println("\n" + "Files Modified betweeen 24 and 27:" + s);
            File fileName_mns_d = new File(s);
//            File[] files_2 = fileName_mns.listFiles();//Lists all the files of directory
            fileName_mns_d.delete();
        }
    }}
}
