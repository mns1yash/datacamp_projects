package javaapplication3;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;

public class DoublyLinkedList {

    Node head; // head of list
    Node tail;
    Node temp;

    /* Doubly Linked list Node*/
    class Node {

        FileObj data;
        Node prev = null;
        Node next = null;

        Node(FileObj data) {
            this.data = data;
        }
    }

    public void addNode(FileObj new_data) {
        Node new_Node = new Node(new_data);

        if ((tail == null && head == null)) {
            head = tail = new_Node;
        } else {
            if (head == tail) {
                temp = head;
                temp.next = new_Node;
                new_Node.prev = temp;
                tail = new_Node;
            } else {
                temp = tail;
                new_Node.prev = tail;
                tail.next = new_Node;
                tail = new_Node;
            }
        }
    }

    public void display() {

        //Node current will point to head          //System.out.print("timestamp is :" + current.data.getTime_stmp() + "\n" + "Path is :" + current.data.getFile_Name() + "\n" + "status is :" + current.data.isStats());  
        temp = head;
        if (temp == null) {
            System.out.println("List is empty");
            return;
        }
        System.out.println("Nodes of doubly linked list: " + "\n");
        while (temp != null) {
            //Prints each node by incrementtail = new_Node;ing the pointer.  
            //head.data = head.prev.data;
            System.out.println("Head Previous:  " + temp.prev);
            System.out.println("Head Value:  " + temp);
            System.out.println("Head Next:  " + temp.next + "\n");
            System.out.print("timestamp is :" + temp.data.getTime_stmp() + "\n" + "Path is :" + temp.data.getFile_Name() + "\n" + "status is :" + temp.data.isStats() + "\n" + "\n");
            System.out.println("tail timestamp is :" + tail.data.getTime_stmp() + "\n" + "tail Path is :" + tail.data.getFile_Name() + "\n" + "tail status is :" + tail.data.isStats() + "\n");
            //System.out.print(" n timestamp is :" + temp.prev.data.getTime_stmp() + "\n" + " n Path is :" + temp.prev.data.getFile_Name() + "\n" + " n status is :" + temp.prev.data.isStats());
            temp = temp.next;
            //tail=tail.next;
        }
    }

    public static void main(String[] args) throws FileNotFoundException, IOException, ParseException {

        Process p;
        File fileName_mns = new File("/root/Desktop/mns_Yaswanth");
        System.out.print(fileName_mns);

        
        
        
        
//        File[] files_1 = fileName_mns.listFiles();//Lists all the files of directory
        long freeSpace = fileName_mns.getFreeSpace();//gets free space of directory
        long totalSpace = fileName_mns.getTotalSpace();
        
        
        
        
        System.out.println("\n" + "Free Space " + freeSpace);
        System.out.println("\n" + "totalSpace" + totalSpace);
        
        
        
        
        long value_ninty = (totalSpace * 90) / 100;
        
        
        
        System.out.println("\n" + "Ninty percent Value " + value_ninty);
        
        
        if (freeSpace < value_ninty) {
            System.out.print("\n" + "Free Space is Available" + "\n");
        } else {
            System.out.println("\n" + "Filled above 90");

//            for (int i = 0; i < files_1.length; i++) {
//                long file_dif = new Date().getTime() - files_1[i].lastModified();
//                long lastChanged_sf = file_dif / 1000;
//                long lastChanged_mf = lastChanged_sf / 60;
//                long lastChanged_hf = lastChanged_mf / 60;
//                long lastChanged_df = lastChanged_hf / 24;
//                System.out.print("\nFile Days" + lastChanged_df);
//                System.out.print("\n" + "Difference " + file_dif);
//                if (lastChanged_df > 1) {
//                    System.out.print("i valueeeeeeeeeeeeeeeeeee" + i);
//                    files_1[i].delete();
//                }
//            }
        }

        DoublyLinkedList dList = new DoublyLinkedList();

        BufferedReader in_1 = new BufferedReader(new FileReader("/root/NetBeansProjects/mns_123/JavaApplication3/src/javaapplication3/Mns.txt"));

        String str_1 = null;
        int Count = 0;
        FileObj foo = null;
        while ((str_1 = in_1.readLine()) != null) {

            System.out.println("\n" + "Loading Line" + Count + "\n" + str_1 + "\n" + "\n" + "Hello string separator" + "\n");
            String[] temp = str_1.split("\t");
            System.out.println("Hello temp 0   " + temp[0] + "\n" + "Hello temp 1   " + temp[1] + "\n" + "Hello temp 2   " + temp[2]);

            Date time_stmp = new SimpleDateFormat("YYYY-M-D hh:mm:ss").parse(temp[0]);
            System.out.println("\n" + "Time Stamp is : " + time_stmp);

            String file_Name = new String(temp[1]);
            System.out.println("File Name is : " + file_Name);

            boolean stats = temp[2].equalsIgnoreCase("1") ? true : false;
            System.out.println("Status value is : " + stats);

            foo = new FileObj(time_stmp, file_Name, stats);
            System.out.println("******Printing obj***************" + foo);

            dList.addNode(foo);
            Count = Count + 1;

        }

        System.out.println("\n" + "Displays all " + "\n");
        dList.display();

    }

    private void delete(File file) {
        boolean success = false;
        if (file.isDirectory()) {
            for (File deleteMe : file.listFiles()) {
                delete(deleteMe);
            }
        }
        success = file.delete();
        if (success) {
            System.out.println(file.getAbsoluteFile() + "Deleted");
        } else {
            System.out.println(file.getAbsoluteFile() + "Deletion failed");
        }
    }
}

//import static javaapplication3.FileObj.stats;
//import static javaapplication3.FileObj.file_Name;
//import static javaapplication3.FileObj.time_stmp;
/**
 *
 * @author root
 */
//Add nodes to the list  
//            dList.addNode(1);  
//            dList.addNode(2);  
//            dList.addNode(3);  
//            dList.addNode(4);  
//            dList.addNode(5);  
//Displays the nodes present in the list  
//        if(head.next.equals(tail)){        Node new_Node = new Node(new_data);
//            head.next = new_Node;
//            tail.prev = new_Node;
//            new_Node.prev = head;
//            new_Node.next=tail;
//        }else{
//            temp = tail.prev;
//            tail.prev = new_Node;
//            temp.next = new_Node;
//            new_Node.prev = temp;
//            new_Node.next=tail;
//            
//        }
//        
//        head.prev = null;
//        tail.next=null;
//        head = new_Node;
//head.next=new_Node;
//new_Node.prev = head = tail;
//        while (head.next!= null) {
//            head = head.next;
//        }

/* 1. allocate node 
    * 2. put in the data */
 /* 3. Make next of new node as head and previous as NULL */
//new_Node.next = head;
//    head.next= new_Node;
//    
//    tail=head;
//    tail.next= new_Node;
//    tail=new_Node;
//    head.prev = tail.prev;
//    tail.next = new_Node;    //new_Node.prev = null;
/* 4. change prev of head node to new node */
//    if (head != null)
//        head.prev = new_Node;
/* 5. move the head to point to the new node */
//    head = new_Node.next;
//
//    @Overridetail = new_Node;
//    public int hashCode() {
//        int hash = 7;
//        hash = 97 * hash + Objects.hashCode(this.head);
//        hash = 97 * hash + Objects.hashCode(this.tail);
//        hash = 97 * hash + Objects.hashCode(this.temp);
//        return hash;
//    }
//
//    @Override
//    public boolean equals(Object obj) {
//        if (this == obj) {
//            return true;
//        }
//        if (obj == null) {
//            return false;
//        }
//        if (getClass() != obj.getClass()) {
//            return false;
//        }
//        final DoublyLinkedList other = (DoublyLinkedList) obj;
//        if (!Objects.equals(this.head, other.head)) {
//            return false;
//        }
//        if (!Objects.equals(this.tail, other.tail)) {
//            return false;
//        }
//        if (!Objects.equals(this.temp, other.temp)) {
//            return false;
//        }
//        return true;
//    }
//addNode() will add a node to the list  
//    public void addNode(FileObj data) {DoublyLinkedList.java:58
//        //Create a new node  
//        Node newNode = new Node(data);
//
//        //If list is empty  
//        if (head == null) {
//            //Both head and tail will point to newNode  
//            head = tail = newNode;
//            //head's previous will point to null  
//            head.previous = null;
//            //tail's next will point to null, as it is the last node of the list  
//            tail.next = null;
//        } else {
//            //newNode will be added after tail such that tail's next will point to newNode  
//            tail.next = newNode;
//            //newNode's previous will point to tail  
//            newNode.previous = tail;
//            //newNode will become new tail  
//            tail = newNode;
//            //As it is last node, tail's next will point to null  
//            tail.next = null;
//        }
//    }
//display() will print out the nodes of the list  
//            System.out.println("new object"+new FileObj(time_stmp, file_Name, stats));
//            dList.addNode(new FileObj(time_stmp, file_Name, stats));
//        public Node(FileObj data, Node prev, Node next) {
//            this.data = data;
//            this.prev = prev;
//            this.next = next;
//        }
// Constructor to create a new node
// next and prev is by default initialized as null
//            head.next = tail;
//            tail.prev = head;
//Represent a node of the doubly linked list  
//    class Node {
//
//        FileObj data;
//        Node previous;
//        Node next;
//
//        public Node(FileObj data) {
//            this.data = data;
//        }
//    }
//Represent the head and tail of the doubly linked list  
//    Node head, tail = null;
// Adding a node at the front of the list

