package javaapplication3;

import java.util.Date;

public class FileObj {
         String file_Name;
         Date time_stmp;
         boolean stats;
        public FileObj(Date time_stmp, String file_Name, boolean stats){
            //System.out.println("timestamp is :"+time_stmp+"\n"+"Path is :"+file_Name+"\n"+"status is :"+stats);
            this.file_Name = file_Name;
            this.time_stmp = time_stmp;
            this.stats = stats;
        }

    @Override
    public String toString() {
        return "FileObj{" + '}';
    }

    public String getFile_Name() {
        return file_Name;
    }

    public void setFile_Name(String file_Name) {
        this.file_Name = file_Name;
    }

    public Date getTime_stmp() {
        return time_stmp;
    }

    public void setTime_stmp(Date time_stmp) {
        this.time_stmp = time_stmp;
    }

    public boolean isStats() {
        return stats;
    }

    public void setStats(boolean stats) {
        this.stats = stats;
    }
}
