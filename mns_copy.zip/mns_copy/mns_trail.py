from sys import maxsize
def tsp(x,y):
    min_path = maxsize
    while True:
        current_path= k = 0
        for i in range(4):
            print("iteraion value ",i)
            current_path += x[k][i]
            print("matrics values",x[k][i])
        k = i
        print("After addition ",current_path)
        print("y value ", y, "x value ", x,"k value ",k)
        current_path += x[k][s]
        print("Current path after for loop",current_path)
        min_path = min(min_path, current_path)
        print("min path",min_path)
        if not gotonextpattern(x):
            break
    return min_path
def gotonextpattern(p):
    n = len(p)
    i = n-2
    while i>=0 and p[i] >= p[i+1]:
        i -= 1  
    if i == -1:
        return False
    j=i+1
    while j<n and p[j] > p[i]:
        j+=1
    j-=1
    p[i], p[j] = p[j], p[i]
    left = i+1
    right = n-1
    while left < right:
        p[left], p[right] = p[right], p[left]
        left += 1
        right -= 1
    return True

if __name__ == "__main__":
    x = [[0, 10,15, 20], 
         [5, 0, 9, 10],
         [6, 13, 0, 12], 
         [8, 8, 9, 0],] 
    s=0
    print(tsp(x,s))