Python 2.7.15 (v2.7.15:ca079a3ea3, Apr 30 2018, 16:30:26) [MSC v.1500 64 bit (AMD64)] on win32
Type "copyright", "credits" or "license()" for more information.
>>> 
>>> 
>>> class c1:
	a = 0
	def __init__(self,a):
		self.a=a

		
>>> class c1:
	a = 0
	def __init__(self,a):
		self.a=a
	def m1(self):
		return "m1 of c1 "

	
>>> obj1=c1(100)
>>> 
>>> obj1.a
100
>>> obj1.m1()
'm1 of c1 '

>>> class c2:
	a = 0
	def __init__(self,a):
		self.a=a
	def m1(self):
		return "m1 of c1 "

	
>>> obj2=c2(50)
>>> obj2.a
50
>>> class c2:
	a = 0
	def m1(self):
		return "m1 of c1 "

	
>>> ob2=c2()
>>> ob2.a
0
>>> ob3=c2()
>>> 0b3.a=30
SyntaxError: invalid token
>>> 0b3.a=30
SyntaxError: invalid token
>>> ob3.a
0
>>> ob3.a=30
>>> ob3.a
30
>>> c1.a
0
>>> c1.a=20
>>> cl.a

Traceback (most recent call last):
  File "<pyshell#33>", line 1, in <module>
    cl.a
NameError: name 'cl' is not defined
>>> c1.a
20
>>> ob2.a
0
>>> c2.a
0
>>> c2.a=20
>>> ob2.a
20
>>> class c3()
SyntaxError: invalid syntax
\
>>> ob2.a
20
>>> ob5=c2()
>>> ob5.a
20
>>> class c2:
	a = 0
	def m1(self):
		return "m1 of c1 "

	
>>> obj1=c2()
>>> obj1.a
0
>>> obj1.a=100
>>> obj1.a
100
>>> obj2=c2()
>>> obj2.a
0
>>> class c2:
	a = 0
	def m1(self,a):
		self.a=a

		
>>> obj1=c2()
>>> obj1.m1(100)
>>> obj1.a
100
>>> obj2=c2()
>>> obj2.a
0
>>> 
>>> class emp():
	name = none
	dep = none
	sal = 0
	emp_id = 0
	def m1(self,name,dep,sal,emp_id):
		self.name=name
		self.dep=dep
		self.sal=sal
		self.emp_id=emp_id

		

Traceback (most recent call last):
  File "<pyshell#72>", line 1, in <module>
    class emp():
  File "<pyshell#72>", line 2, in emp
    name = none
NameError: name 'none' is not defined
>>> class emp():
	name = null
	dep = null
	sal = 0
	emp_id = 0
	def m1(self,name,dep,sal,emp_id):
		self.name=name
		self.dep=dep
		self.sal=sal
		self.emp_id=emp_id

		

Traceback (most recent call last):
  File "<pyshell#74>", line 1, in <module>
    class emp():
  File "<pyshell#74>", line 2, in emp
    name = null
NameError: name 'null' is not defined
>>> class emp():
	name = 'null'
	dep = 'null'
	sal = 0
	emp_id = 0
	def m1(self,name,dep,sal,emp_id):
		self.name=name
		self.dep=dep
		self.sal=sal
		self.emp_id=emp_id

		
>>> 
>>> obj1=emp()
>>> obj1.m1()

Traceback (most recent call last):
  File "<pyshell#79>", line 1, in <module>
    obj1.m1()
TypeError: m1() takes exactly 5 arguments (1 given)
>>> class emp():
	name = 'null'
	dep = 'null'
	sal = 0
	emp_id = 0
	def __init__(self,name,dep,sal,emp_id):
		self.name=name
		self.dep=dep
		self.sal=sal
		self.emp_id=emp_id
	def emp_det(self):
		print " employee number ={} ".format(self.emp_id)
		print " employee name ={} ".format(self.name)
		print " employee department ={} ".format(self.dep)
		print " employee salary ={} ".format(self.sal)

		
>>> 
>>> obj1=emp()

Traceback (most recent call last):
  File "<pyshell#88>", line 1, in <module>
    obj1=emp()
TypeError: __init__() takes exactly 5 arguments (1 given)
>>> class emp():
	def __init__(self,name=none,dep=none,sal=none,emp_id=none):
		self.name=name
		self.dep=dep
		self.sal=sal
		self.emp_id=emp_id
	def emp_det(self):
		print " employee number ={} ".format(self.emp_id)
		print " employee name ={} ".format(self.name)
		print " employee department ={} ".format(self.dep)
		print " employee salary ={} ".format(self.sal)

		

Traceback (most recent call last):
  File "<pyshell#90>", line 1, in <module>
    class emp():
  File "<pyshell#90>", line 2, in emp
    def __init__(self,name=none,dep=none,sal=none,emp_id=none):
NameError: name 'none' is not defined
>>> class emp():
	def __init__(self,name=None,dep=None,sal=None,emp_id=None):
		self.name=name
		self.dep=dep
		self.sal=sal
		self.emp_id=emp_id
	def emp_det(self):
		print " employee number ={} ".format(self.emp_id)
		print " employee name ={} ".format(self.name)
		print " employee department ={} ".format(self.dep)
		print " employee salary ={} ".format(self.sal)

		
>>> obj1.emp()

Traceback (most recent call last):
  File "<pyshell#93>", line 1, in <module>
    obj1.emp()
AttributeError: emp instance has no attribute 'emp'
>>> obj1=emp()
>>> obj1.name
>>> obj1.name
>>> print obj1.name
None
>>> class emp1():
	name = None
	dep = None
	sal = None
	emp_id = None
	def __init__(self,name,dep,sal,emp_id):
		self.name=name
		self.dep=dep
		self.sal=sal
		self.emp_id=emp_id
	def emp_det(self):
		print " employee number ={} ".format(self.emp_id)
		print " employee name ={} ".format(self.name)
		print " employee department ={} ".format(self.dep)
		print " employee salary ={} ".format(self.sal)

		
>>> obj2=emp1()

Traceback (most recent call last):
  File "<pyshell#100>", line 1, in <module>
    obj2=emp1()
TypeError: __init__() takes exactly 5 arguments (1 given)
>>> class emp1():
	name = None
	dep = None
	sal = None
	emp_id = None
	def __init__(self):
		self.name=name
		self.dep=dep
		self.sal=sal
		self.emp_id=emp_id
	def emp_det(self):
		print " employee number ={} ".format(self.emp_id)
		print " employee name ={} ".format(self.name)
		print " employee department ={} ".format(self.dep)
		print " employee salary ={} ".format(self.sal)

		
>>> obj2=emp1()

Traceback (most recent call last):
  File "<pyshell#103>", line 1, in <module>
    obj2=emp1()
  File "<pyshell#102>", line 7, in __init__
    self.name=name
NameError: global name 'name' is not defined
>>> class emp1():
	name = None
	dep = None
	sal = None
	emp_id = None
	def __init__(self,name=self.name,dep=self.dep,sal=self.sal,emp_id=self.emp_id):
		self.name=name
		self.dep=dep
		self.sal=sal
		self.emp_id=emp_id
	def emp_det(self):
		print " employee number ={} ".format(self.emp_id)
		print " employee name ={} ".format(self.name)
		print " employee department ={} ".format(self.dep)
		print " employee salary ={} ".format(self.sal)

		

Traceback (most recent call last):
  File "<pyshell#119>", line 1, in <module>
    class emp1():
  File "<pyshell#119>", line 6, in emp1
    def __init__(self,name=self.name,dep=self.dep,sal=self.sal,emp_id=self.emp_id):
NameError: name 'self' is not defined
>>> 
>>> 
>>> 
>>> class emp():
	def __init__(self,name=None,dep=None,sal=None,emp_id=None):
		self.name=name
		self.dep=dep
		self.sal=sal
		self.emp_id=emp_id
	def emp_det(self):
		print " employee number ={} ".format(self.emp_id)
		print " employee name ={} ".format(self.name)
		print " employee department ={} ".format(self.dep)
		print " employee salary ={} ".format(self.sal)

		
>>> obj1.emp(yashu,cse,1000,100)

Traceback (most recent call last):
  File "<pyshell#125>", line 1, in <module>
    obj1.emp(yashu,cse,1000,100)
AttributeError: emp instance has no attribute 'emp'
>>> obj1=emp(yashu,cse,1000,100)

Traceback (most recent call last):
  File "<pyshell#126>", line 1, in <module>
    obj1=emp(yashu,cse,1000,100)
NameError: name 'yashu' is not defined
>>> class emp():
	def __init__(self,name=None,dep=None,sal=None,emp_id=None):
		self.name=name
		self.dep=dep
		self.sal=sal
		self.emp_id=emp_id
	def emp_det(self):
		print " employee number ={} ".format(self.emp_id)
		print " employee name ={} ".format(self.name)
		print " employee department ={} ".format(self.dep)
		print " employee salary ={} ".format(self.sal)

		
>>> obj4=emp('yashu', 'cse', 1000, 100)

>>> print obj4.emp_det
<bound method emp.emp_det of <__main__.emp instance at 0x0000000006129588>>
>>> obj4.emp_det
<bound method emp.emp_det of <__main__.emp instance at 0x0000000006129588>>
>>> obj4.emp_det()
 employee number =100 
 employee name =yashu 
 employee department =cse 
 employee salary =1000 
>>> 
>>> class c2():
	def __init__(self,a,b):
		self.a=a
		self.b=b
	def __init__(self,c,d):
		self.c=c
		self.d=d
	def prnt():
		print a
		print b
		print c
		print d

		
>>> obj1=c2(2,3)
>>> 
>>> obj1.prnt()

Traceback (most recent call last):
  File "<pyshell#149>", line 1, in <module>
    obj1.prnt()
TypeError: prnt() takes no arguments (1 given)
>>> obj1.prnt()

Traceback (most recent call last):
  File "<pyshell#150>", line 1, in <module>
    obj1.prnt()
TypeError: prnt() takes no arguments (1 given)
>>> class c2():
	def __init__(self,a,b):
		self.a=a
		self.b=b
	def __init__(self,c,d):
		self.c=c
		self.d=d
	def prnt(self):
		print a
		print b
		print c
		print d

		
>>> obj1=c2(2,3)
>>> 
>>> obj1.prnt()

Traceback (most recent call last):
  File "<pyshell#155>", line 1, in <module>
    obj1.prnt()
  File "<pyshell#152>", line 9, in prnt
    print a
NameError: global name 'a' is not defined
>>> class c2():
	def __init__(self,a=None,b=None):
		self.a=a
		self.b=b
	def __init__(self,c,d):
		self.c=c
		self.d=d
	def prnt(self):
		print a
		print b
		print c
		print d

		
>>> obj1=c2(3,3)
>>> obj1.prnt()

Traceback (most recent call last):
  File "<pyshell#159>", line 1, in <module>
    obj1.prnt()
  File "<pyshell#157>", line 9, in prnt
    print a
NameError: global name 'a' is not defined
>>> class c2():
	def __init__(self,a=None,b=None):
		self.a=a
		self.b=b
		
	def __init__(self,c,d):
		self.c=c
		self.d=d
	def prnt(self):
		print a
		print b
		print c
		print d

		
>>> a = 10
>>> b='Hello'
>>> a.__add__(20)
30
>>> a.__class__
<type 'int'>
>>> b.__add__('Raju')
'HelloRaju'
>>> b.__class__
<type 'str'>
>>> 'Hello'.__add__(' Yashu')
'Hello Yashu'
>>> a.__add(989876543234567899876543234567886543345676542345678900987654)

Traceback (most recent call last):
  File "<pyshell#169>", line 1, in <module>
    a.__add(989876543234567899876543234567886543345676542345678900987654)
AttributeError: 'int' object has no attribute '__add'
>>> a.__add__(989876543234567899876543234567886543345676542345678900987654)
NotImplemented
>>> 10+928989797896346087680476083746586328465
928989797896346087680476083746586328475L
>>> 10+98798758678568327468732658736485623847568374658374658374658374687345987346587324538724563865287345
98798758678568327468732658736485623847568374658374658374658374687345987346587324538724563865287355L
>>> b=98798758678568327468732658736485623847568374658374658374658374687345987346587324538724563865287345
>>> type b
SyntaxError: invalid syntax
>>> type 'b'
SyntaxError: invalid syntax
>>> b.type

Traceback (most recent call last):
  File "<pyshell#176>", line 1, in <module>
    b.type
AttributeError: 'long' object has no attribute 'type'
>>> a+b
98798758678568327468732658736485623847568374658374658374658374687345987346587324538724563865287355L
>>> b.type()

Traceback (most recent call last):
  File "<pyshell#178>", line 1, in <module>
    b.type()
AttributeError: 'long' object has no attribute 'type'
>>> type(b)
<type 'long'>
>>> type(a)
<type 'int'>
>>> print int(b)
98798758678568327468732658736485623847568374658374658374658374687345987346587324538724563865287345
>>> 
