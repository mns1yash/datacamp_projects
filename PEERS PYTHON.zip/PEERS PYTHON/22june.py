Python 2.7.15 (v2.7.15:ca079a3ea3, Apr 30 2018, 16:30:26) [MSC v.1500 64 bit (AMD64)] on win32
Type "copyright", "credits" or "license()" for more information.
>>> 
=============== RESTART: C:\Users\MY PC\pythonfiles\pyfile1.py ===============

Traceback (most recent call last):
  File "C:\Users\MY PC\pythonfiles\pyfile1.py", line 1, in <module>
    from abc import ABC,abstractmethod
ImportError: cannot import name ABC
>>> import abc
>>> 
=============== RESTART: C:\Users\MY PC\pythonfiles\pyfile1.py ===============

Traceback (most recent call last):
  File "C:\Users\MY PC\pythonfiles\pyfile1.py", line 1, in <module>
    from abc import ABC,abstractmethod
ImportError: cannot import name ABC
>>> 
=============== RESTART: C:\Users\MY PC\pythonfiles\pyfile1.py ===============

Traceback (most recent call last):
  File "C:\Users\MY PC\pythonfiles\pyfile1.py", line 1, in <module>
    from abc import ABC,abstractmethod
ImportError: cannot import name ABC
>>> 
=============== RESTART: C:\Users\MY PC\pythonfiles\pyfile1.py ===============

Traceback (most recent call last):
  File "C:\Users\MY PC\pythonfiles\pyfile1.py", line 2, in <module>
    from abc import ABC,abstractmethod
ImportError: cannot import name ABC
>>> 
=============== RESTART: C:\Users\MY PC\pythonfiles\pyfile1.py ===============

Traceback (most recent call last):
  File "C:\Users\MY PC\pythonfiles\pyfile1.py", line 2, in <module>
    from abc import ABC,abstractmethod
ImportError: cannot import name ABC
>>> import threading
>>> import time
>>> 
===================== RESTART: H:/PEERS PYTHON/thread.py =====================

Traceback (most recent call last):
  File "H:/PEERS PYTHON/thread.py", line 10, in <module>
    printnum1(n)
  File "H:/PEERS PYTHON/thread.py", line 3, in printnum1
    time.sleep(0.3)
NameError: global name 'time' is not defined
>>> 
===================== RESTART: H:/PEERS PYTHON/thread.py =====================
0
1
2
3
4
5
6
7
8
9
10
>>> 
===================== RESTART: H:/PEERS PYTHON/thread.py =====================
0
1
2
3
4
5
6
7
8
9
10
>>> 
====================== RESTART: H:/PEERS PYTHON/th2.py ======================
>>> 
===================== RESTART: H:/PEERS PYTHON/thread.py =====================
0
1
2
3
4
5
6
7
8
9
10
10
9
8
7
6
5
4
3
2
1
>>> 
================== RESTART: H:/PEERS PYTHON/threadinng1.py ==================
010

19

28

37

46

55

64

73

82

91

10
>>> 
================== RESTART: H:/PEERS PYTHON/threadinng1.py ==================
010

19

28

37

46

55

64

73

82

91

10
 done 
>>> 
