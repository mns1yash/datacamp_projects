Python 2.7.15 (v2.7.15:ca079a3ea3, Apr 30 2018, 16:30:26) [MSC v.1500 64 bit (AMD64)] on win32
Type "copyright", "credits" or "license()" for more information.
>>> Type "copyright", "credits" or "license()" for more information.
SyntaxError: invalid syntax
>>> 
>>> class c1():
	def m1(self):
		return "m1 1"

	
>>> class c1():
	def m1(self,a):
		self.a=a
		return self.a
	def m1(self,a,b):
		self.a=a
		self.b=b
		return self.a,self.b
	def m1(self,a,b,c):
		self.a=a
		self.b=b
		self.c=c
		return self.a,self.b.self.c

	
>>> c1obj1=c1()
>>> c1obj1.m1(1,2,3)

Traceback (most recent call last):
  File "<pyshell#19>", line 1, in <module>
    c1obj1.m1(1,2,3)
  File "<pyshell#17>", line 13, in m1
    return self.a,self.b.self.c
AttributeError: 'int' object has no attribute 'self'
>>> c1obj1.m1(1,2,3)

Traceback (most recent call last):
  File "<pyshell#20>", line 1, in <module>
    c1obj1.m1(1,2,3)
  File "<pyshell#17>", line 13, in m1
    return self.a,self.b.self.c
AttributeError: 'int' object has no attribute 'self'
>>> class c1():
	def m1(self,a):
		self.a=a
		return self.a
	def m1(self,a,b):
		self.a=a
		self.b=b
		return self.a,self.b
	def m1(self,a,b,c):
		self.a=a
		self.b=b
		self.c=c
		return self.a,self.b,self.c

	
>>> c1obj1=c1()
>>> c1obj1.m1(1,2,3)
(1, 2, 3)
>>> class c2():
	def m2(self, a=None, b=None, c=None);
	
SyntaxError: invalid syntax
>>> class c2():
	def m2(self, a=None, b=None, c=None):
		if a is not None and b is None and c is None :
			return self.a
		elif a is not None and b is not None and c is None :
			return self.a, self.b
		elif a is not None and b is not None and c is not None :
			return self.a, self.b, self.c
		else:
			return "Provide values for a , b and c "

		
>>> ob2c2=c2()
>>> ob2c2.m2(1)

Traceback (most recent call last):
  File "<pyshell#38>", line 1, in <module>
    ob2c2.m2(1)
  File "<pyshell#36>", line 4, in m2
    return self.a
AttributeError: c2 instance has no attribute 'a'
>>> ob2c2.m2(2,3,4)

Traceback (most recent call last):
  File "<pyshell#39>", line 1, in <module>
    ob2c2.m2(2,3,4)
  File "<pyshell#36>", line 8, in m2
    return self.a, self.b, self.c
AttributeError: c2 instance has no attribute 'a'
>>> class c2():
	def m2(self,a=None,b=None,c=None):
		if a is not None and b is None and c is None :
			return self.a
		elif a is not None and b is not None and c is None :
			return self.a,self.b
		elif a is not None and b is not None and c is not None :
			return self.a,self.b,self.c
		else:
			return "Provide values for a , b and c "

		
>>> ob2c2=c2()
>>> ob2c2.m2(2)

Traceback (most recent call last):
  File "<pyshell#43>", line 1, in <module>
    ob2c2.m2(2)
  File "<pyshell#41>", line 4, in m2
    return self.a
AttributeError: c2 instance has no attribute 'a'
>>> ob2c2.m2()
'Provide values for a , b and c '
>>> class c2():
	def m2(self,a=None,b=None,c=None):
		if a is not None and b is None and c is None:
			return self.a
		elif a is not None and b is not None and c is None:
			return self.a,self.b
		elif a is not None and b is not None and c is not None:
			return self.a,self.b,self.c
		else:
			return "Provide values for a , b and c "

		
>>> ob2c2=c2()
>>> ob2c2.m2()
'Provide values for a , b and c '
>>> ob2c2.m2(1)

Traceback (most recent call last):
  File "<pyshell#49>", line 1, in <module>
    ob2c2.m2(1)
  File "<pyshell#46>", line 4, in m2
    return self.a
AttributeError: c2 instance has no attribute 'a'
>>> class c2():
	def m2(self,a=None,b=None,c=None):
		self.a=a
		self.b=b
		self.c=c
		if a is not None and b is None and c is None:
			return self.a
		elif a is not None and b is not None and c is None:
			return self.a,self.b
		elif a is not None and b is not None and c is not None:
			return self.a,self.b,self.c
		else:
			return "Provide values for a , b and c "

		
>>> c2ob2=c2()
>>> c2ob2.m2(1)
1
>>> class c2():
	def m2(self,a=None,b=None,c=None):
		self.a=a
		self.b=b
		self.c=c
		if a is not None and b is None and c is None:
			return a
		elif a is not None and b is not None and c is None:
			return self.a,self.b
		elif a is not None and b is not None and c is not None:
			return self.a,self.b,self.c
		else:
			return "Provide values for a , b and c "

		
>>> ob2=c2()
>>> ob2.m2(1)
1
>>> class c2():
	def m2(self,a=None,b=None,c=None):
		self.a=a
		self.b=b
		self.c=c
		if a is not None and b is None and c is None:
			return a
		elif a is not None and b is not None and c is None:
			return a,b
		elif a is not None and b is not None and c is not None:
			return a,b,c
		else:
			return "Provide values for a , b and c "

		
>>> c2ob2=c2()
>>> c2ob2.m2(1,2)
(1, 2)
>>> c2ob2.m2(a=10,c=20,b=40)
(10, 40, 20)
>>> 
>>> 

>>> 

>>> 
>>> 
>>> 

>>> 
>>> 
>>> 
>>> 
>>> 
>>> 
>>> 
>>> 
>>> 
>>> 

>>> 
>>> 
