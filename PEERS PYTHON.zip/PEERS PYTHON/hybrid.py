class c12():
    def m12(self):
        return " m12  of class 12 "

class c13():
    def m12(self):
        return " m12 of class 13"


class c14(c13,c12):
    def m14(self):
        print(c13.m12(self))
        print(c12.m12(self))
        return "m14 of c14"

class c15(c14):
    def m15(self):
        return " m15 of class 15"

class c16(c14):
    def m16(self):
        return " m16 of class 16"

c15obj1=c15()
c16obj1=c16()
