
from abc import ABC,abstractmethod

class c1(ABC):
    @abstractmethod
    def m1(self):
        pass

class c2(c1):
    def m2(self):
        return("m2 of c2")

class c3(c1):
    def m3(self):
        return("m3 of c3")
