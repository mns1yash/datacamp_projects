class c3():
    __x=100
    __y="Yashu"
    _z=0
    def __init__(self):
        self.__x=100
        self.__y="m yashu"
        self._z=50
    def show1(self):
        print "Yashu value is "+ str(self.__x)
        
c3obj3=c3()
