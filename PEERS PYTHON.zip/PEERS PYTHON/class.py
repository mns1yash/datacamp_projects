Python 2.7.15 (v2.7.15:ca079a3ea3, Apr 30 2018, 16:30:26) [MSC v.1500 64 bit (AMD64)] on win32
Type "copyright", "credits" or "license()" for more information.
>>> import cx_Oracle
>>> con = cx_ORacle.connect

Traceback (most recent call last):
  File "<pyshell#1>", line 1, in <module>
    con = cx_ORacle.connect
NameError: name 'cx_ORacle' is not defined
>>> 
>>> con = cx_Oracle.connect('scott/tiger@orcl')
>>> cur = con.cursor()
>>> cur.execute('select * from dept')
<cx_Oracle.Cursor on <cx_Oracle.Connection to scott@orcl>>
>>> for print i in cur:
	
SyntaxError: invalid syntax
>>> for print i in cur:
	
SyntaxError: invalid syntax
>>> for i in cur:
	print i

(10, 'ACCOUNTING', 'NEW YORK')
(20, 'RESEARCH', 'DALLAS')
(30, 'SALES', 'CHICAGO')
(40, 'OPERATIONS', 'BOSTON')
>>> cur.execute('insert into student values(102,'raju','python');
	    
SyntaxError: invalid syntax
>>> cur.execute("insert into student values(102,'raju','python'")

Traceback (most recent call last):
  File "<pyshell#12>", line 1, in <module>
    cur.execute("insert into student values(102,'raju','python'")
DatabaseError: ORA-00917: missing comma
>>> cur.execute('insert into student values(102,'raju','python'))
	    
SyntaxError: invalid syntax
>>> cur.execute('insert into student values(102,'raju','python')')
SyntaxError: invalid syntax
>>> cur.execute("insert into student values(102,'raju','python')")
>>> cur.execute("commit")
>>> var = cur.execute("select * from student where course='python' ")
>>> print var
<cx_Oracle.Cursor on <cx_Oracle.Connection to scott@orcl>>
>>> sid = 103
>>> sname= 'yash'
>>> course='sql'
>>> cur.execute("insert into student values ({},{},{})".format(sid,sname,course))

Traceback (most recent call last):
  File "<pyshell#22>", line 1, in <module>
    cur.execute("insert into student values ({},{},{})".format(sid,sname,course))
DatabaseError: ORA-00984: column not allowed here
>>> cur.execute("insert into student values ({},{},{}).format(sid,sname,course)")

Traceback (most recent call last):
  File "<pyshell#23>", line 1, in <module>
    cur.execute("insert into student values ({},{},{}).format(sid,sname,course)")
DatabaseError: ORA-00936: missing expression
>>> cur.execute("insert into student values ({},{},{}.format(sid,sname,course))")

Traceback (most recent call last):
  File "<pyshell#24>", line 1, in <module>
    cur.execute("insert into student values ({},{},{}.format(sid,sname,course))")
DatabaseError: ORA-00936: missing expression
>>> cur.execute("insert into student values({},{},{}.format(sid,sname,course))")

Traceback (most recent call last):
  File "<pyshell#25>", line 1, in <module>
    cur.execute("insert into student values({},{},{}.format(sid,sname,course))")
DatabaseError: ORA-00936: missing expression
>>> cur.execute("insert into student values({},{},{}.format(sid,sname,course))")

Traceback (most recent call last):
  File "<pyshell#26>", line 1, in <module>
    cur.execute("insert into student values({},{},{}.format(sid,sname,course))")
DatabaseError: ORA-00936: missing expression
>>> cur.execute("insert into student values({},{},{}.format(sid,sname,course))")

Traceback (most recent call last):
  File "<pyshell#27>", line 1, in <module>
    cur.execute("insert into student values({},{},{}.format(sid,sname,course))")
DatabaseError: ORA-00936: missing expression
>>> 
>>> class cn1():
	a = 100
	def m1():
		b = 200
		return " m1 if class cn1"

>>> obj1=cn1()
>>> obj1.
SyntaxError: invalid syntax
>>> obj1.a
100
>>> obj1.m1
<bound method cn1.m1 of <__main__.cn1 instance at 0x0000000005D8C708>>
>>> obj1.m1
<bound method cn1.m1 of <__main__.cn1 instance at 0x0000000005D8C708>>
>>> obj1.m1()

Traceback (most recent call last):
  File "<pyshell#40>", line 1, in <module>
    obj1.m1()
TypeError: m1() takes no arguments (1 given)
>>> obj1.m1()

Traceback (most recent call last):
  File "<pyshell#41>", line 1, in <module>
    obj1.m1()
TypeError: m1() takes no arguments (1 given)
>>> print obj1.m1()

Traceback (most recent call last):
  File "<pyshell#42>", line 1, in <module>
    print obj1.m1()
TypeError: m1() takes no arguments (1 given)
>>> print obj1.m1(b)

Traceback (most recent call last):
  File "<pyshell#43>", line 1, in <module>
    print obj1.m1(b)
NameError: name 'b' is not defined
>>> print obj1.m1()

Traceback (most recent call last):
  File "<pyshell#44>", line 1, in <module>
    print obj1.m1()
TypeError: m1() takes no arguments (1 given)
>>> class cn1():
	a = 100
	def m1():
		b = 200
		return " m1 if class cn1"

>>> class cn1():
	a = 100
	def m1():
		b = 200
		return " m1 if class cn1"
obj1=cn1
SyntaxError: invalid syntax
>>> class cn1():
	a = 100
	def m1():
		b = 200
		return " m1 if class cn1"
	obj1=cn1

	
>>> print obj1.m1()

Traceback (most recent call last):
  File "<pyshell#52>", line 1, in <module>
    print obj1.m1()
TypeError: m1() takes no arguments (1 given)
>>> class cn1():
	a = 100
	def m1():
		b = 200
		return"m1 if class cn1"

	
>>> print obj1.m1()

Traceback (most recent call last):
  File "<pyshell#55>", line 1, in <module>
    print obj1.m1()
TypeError: m1() takes no arguments (1 given)
>>> class cn2():
	cc=100
	def m2():
		return"m1 of class c1 "

	
>>> print cn2.
SyntaxError: invalid syntax
>>> print cn2.cc
100
>>> print cn2.m2
<unbound method cn2.m2>
>>> obj2=cn2()
>>> print obj2
<__main__.cn2 instance at 0x0000000005D8CE88>
>>> obj2
<__main__.cn2 instance at 0x0000000005D8CE88>
>>> print obj2.cc
100
>>> print obj2.m2
<bound method cn2.m2 of <__main__.cn2 instance at 0x0000000005D8CE88>>
>>> print obj2.m2()

Traceback (most recent call last):
  File "<pyshell#70>", line 1, in <module>
    print obj2.m2()
TypeError: m2() takes no arguments (1 given)
>>> class cn2():
	cc=100
	def m2(self):
		bb=200
		return"m1 of class c1 "

	
>>> print cn2.cc
100
>>> print cn2.bb

Traceback (most recent call last):
  File "<pyshell#74>", line 1, in <module>
    print cn2.bb
AttributeError: class cn2 has no attribute 'bb'
>>> print cn2.m2
<unbound method cn2.m2>
>>> ob1=cn2
>>> ob1.cc
100
>>> ob1.m2
<unbound method cn2.m2>
>>> ob1.m2()

Traceback (most recent call last):

  File "<pyshell#79>", line 1, in <module>
    ob1.m2()
TypeError: unbound method m2() must be called with cn2 instance as first argument (got nothing instead)
>>> print ob1.m2()

Traceback (most recent call last):
  File "<pyshell#80>", line 1, in <module>
    print ob1.m2()
TypeError: unbound method m2() must be called with cn2 instance as first argument (got nothing instead)
>>> print ob1.m2
<unbound method cn2.m2>
>>> ob1=cn2
>>> print ob1.m2
<unbound method cn2.m2>
>>> print obj2.m2()

Traceback (most recent call last):
  File "<pyshell#84>", line 1, in <module>
    print obj2.m2()
TypeError: m2() takes no arguments (1 given)
>>> File "<pyshell#80>", line 1, in <module>
SyntaxError: invalid syntax
>>> 
>>> 
>>> 
>>> 
>>> 
>>> class cn1():
	a = 100
	def m1(self):
		b = 200
		return "m1 of class cn1"

	
>>> obj1=cn1()
>>> print obj1.
SyntaxError: invalid syntax
>>> 
>>> print obj1.a
100
>>> print obj1.m1
<bound method cn1.m1 of <__main__.cn1 instance at 0x0000000005D8CD48>>
>>> print obj1.m1()
m1 of class cn1
>>> ob1=cn2
>>> ob1.m2()

Traceback (most recent call last):
  File "<pyshell#104>", line 1, in <module>
    ob1.m2()
TypeError: unbound method m2() must be called with cn2 instance as first argument (got nothing instead)
>>> ob1=cn2()
>>> ob1.m2()
'm1 of class c1 '
>>> 
