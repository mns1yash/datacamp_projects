class c1():
    a =100
    _b=200
    __c=300
    def m1(self):
         return " Method m1 of class c1 "

c1obj1=c1()
