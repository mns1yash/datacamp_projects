import time
import threading

def printnum1(n):
    for i in range(n+1):
        time.sleep(0.3)
        print(i)
def printnum2(n):
    for i in range(n,0,-1):
        time.sleep(0.3)
        print(i)
n=10

t1=threading.Thread(target=printnum1,args=(n,))
t2=threading.Thread(target=printnum2,args=(n,))

t1.start()
t2.start()

t1.join()
t2.join()

print(" done ")
