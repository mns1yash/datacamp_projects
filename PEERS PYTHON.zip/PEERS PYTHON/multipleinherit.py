class c6():
    def m6(self):
        return " m6  of class 6 "


    

class c7():
    def m6(self):
        return " m6 of class 7"


class c8(c6,c7):
    def m8(self):
        print c6.m6(self)
        print c7.m6(self)
        return "m8 of c8"



c8obj1= c8()





