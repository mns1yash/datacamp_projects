class c1():
    a =0
    def m1(self):
        print self.a
class c2():
    a=0
    def __init__(self,a):
        self.a =a
    def m1(self):
        print self.a
class c3():
    a=0
    def m1(self,a):
        self.a=a

c1obj1=c1()
c2obj1=c2(1)
c3obj1=c3()
