import time
def printnum2(n):
    for i in range(n,0,n-1):
        time.sleep(0.3)
        print(i)
n=10
printnum2(n)
