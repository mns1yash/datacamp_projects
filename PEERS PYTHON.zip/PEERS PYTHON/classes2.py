Python 2.7.15 (v2.7.15:ca079a3ea3, Apr 30 2018, 16:30:26) [MSC v.1500 64 bit (AMD64)] on win32
Type "copyright", "credits" or "license()" for more information.
>>> import os
>>> import cx_Oracle
>>> con =  cx_Oracle.connect('scott/tiger@orcl')
>>> cur = con.cursor()
>>> cur.execute('select * from student')
<cx_Oracle.Cursor on <cx_Oracle.Connection to scott@orcl>>
>>> for i in cur:
	print i

	
(101, 'scott', 'oracle')
(102, 'raju', 'python')
>>> class c1():
	a = 100
	def m1(self):
		return "m1 of class c1"

	
>>> c1obj1=c1()
>>> print(dir(c1obj1))
['__doc__', '__module__', 'a', 'm1']
>>> c1obj1.m1()
'm1 of class c1'
>>> c1obj1.__class__
<class __main__.c1 at 0x0000000005990288>
>>> class c2():
	"""This is a class of my secind class lecture"""
	x=100
	def m1(self):
		return "m1 of class c2"

	
>>> c2obj1=c2()
>>> print(c2obj1.__doc__())

Traceback (most recent call last):
  File "<pyshell#25>", line 1, in <module>
    print(c2obj1.__doc__())
TypeError: 'str' object is not callable
>>> c2obj1.__doc__
'This is a class of my secind class lecture'
>>> print(dir(c2obj1))
['__doc__', '__module__', 'm1', 'x']
>>> print(dir(c2obj1))
['__doc__', '__module__', 'm1', 'x']
>>> c2obj1=2000
>>> print(c2obj1.x)

Traceback (most recent call last):
  File "<pyshell#34>", line 1, in <module>
    print(c2obj1.x)
AttributeError: 'int' object has no attribute 'x'
>>> c2obj1.x=200

Traceback (most recent call last):
  File "<pyshell#35>", line 1, in <module>
    c2obj1.x=200
AttributeError: 'int' object has no attribute 'x'
>>> c2obj1.x=200

Traceback (most recent call last):
  File "<pyshell#36>", line 1, in <module>
    c2obj1.x=200
AttributeError: 'int' object has no attribute 'x'
>>> c2obj1.__doc__
"int(x=0) -> int or long\nint(x, base=10) -> int or long\n\nConvert a number or string to an integer, or return 0 if no arguments\nare given.  If x is floating point, the conversion truncates towards zero.\nIf x is outside the integer range, the function returns a long instead.\n\nIf x is not a number or if base is given, then x must be a string or\nUnicode object representing an integer literal in the given base.  The\nliteral can be preceded by '+' or '-' and be surrounded by whitespace.\nThe base defaults to 10.  Valid bases are 0 and 2-36.  Base 0 means to\ninterpret the base from the string as an integer literal.\n>>> int('0b100', base=0)\n4"
>>> class c3():
	""" This is about a constructor"""
	a = 100
	def__init__(self):
		
SyntaxError: invalid syntax
>>> class c3():
	""" This is about a constructor"""
	a = 100
	def __init__(self):
		return "C3 is class of constructor"

	
>>> class c3():
	""" This is about a constructor"""
	a = 100
	def __init__(self):
		return "C3 is class of constructor"
	def m1(self):
		return "m1 of class c3"

	
>>> c3obj1=c3()

Traceback (most recent call last):
  File "<pyshell#49>", line 1, in <module>
    c3obj1=c3()
TypeError: __init__() should return None
>>> class c3():
	""" This is about a constructor"""
	a = 100
	def __init__(self):
		print "C3 is class of constructor"
	def m1(self):
		return "m1 of class c3"

	
>>> c3obj1=c3()
C3 is class of constructor
>>> print(c3obj1.m1())
m1 of class c3
>>> 
>>> 
>>> 
>>> c3obj1.a=200
>>> print c3obj1.a'
SyntaxError: EOL while scanning string literal
>>> print c3obj1.a
200
>>> class rectangle():
	def __init__(self,l,b):
		self.l=l
		self.b=b
	def getarea(self):
		return self.l*self.b

	
>>> rect1=rectangle(6,5)
>>> rect1.getarea()
30
>>> print rect1.l
6
>>> print rect1.self.l

Traceback (most recent call last):
  File "<pyshell#70>", line 1, in <module>
    print rect1.self.l
AttributeError: rectangle instance has no attribute 'self'
>>> print self.l

Traceback (most recent call last):
  File "<pyshell#71>", line 1, in <module>
    print self.l
NameError: name 'self' is not defined
>>> rect1=rectangle(10,20)
>>> rect1.getrea()

Traceback (most recent call last):
  File "<pyshell#73>", line 1, in <module>
    rect1.getrea()
AttributeError: rectangle instance has no attribute 'getrea'
>>> rect1.getarea()
200
>>> 
