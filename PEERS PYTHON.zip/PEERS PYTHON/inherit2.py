class c3():
    def m3(self):
        return "m3 of class 3"



class c4(c3):
    def m4(self):
        return " m4 ofd class 4 "



class c5(c4):
    def m5(self):
        return " m5 of class 5 "


'''
def main(self):
    c5obj1=c5()
    c5obj1.m3()
    c5obj1.m4()
    c5obj1.m5()
    '''

if __name__ == "__main__":
    c5obj1=c5()
    c5obj1.m3()
    c5obj1.m4()
    c5obj1.m5()
    
    
