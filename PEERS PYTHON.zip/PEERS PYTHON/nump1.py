# -*- coding: utf-8 -*-
"""
Created on Thu Jun 28 11:12:08 2018

@author: Yash
"""

import numpy as np
np.abs(-100)
np.absolute(-20)
#np.absolute_import(-100)
np.add(2,3)
np.allclose()
np.argpartition(5,0)
l1=[]
np.append(l1,2)
np.cumprod(2)
help(np.cumprod)



import pandas as pd
fobj= open("H:\Database1.csv","r")
news = pd.read_csv(".csv",error_bad_lines=False, index_col=0, dtype='unicode')