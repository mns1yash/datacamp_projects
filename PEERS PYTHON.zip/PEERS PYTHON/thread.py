import time
import threading

def printnum1(n):
    for i in range(n+1):
        time.sleep(0.3)
        print(i)
def printnum2(n):
    for i in range(n,0,-1):
        time.sleep(0.3)
        print(i)
n=10
printnum1(n)
printnum2(n)
