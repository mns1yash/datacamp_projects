#Python 2.7.15 (v2.7.15:ca079a3ea3, Apr 30 2018, 16:30:26) [MSC v.1500 64 bit (AMD64)] on win32
Type "copyright", "credits" or "license()" for more information.
>>> 
===================== RESTART: H:/PEERS PYTHON/encap1.py =====================

Traceback (most recent call last):
  File "H:/PEERS PYTHON/encap1.py", line 17, in <module>
    c2obj1=c2()
TypeError: __init__() takes exactly 2 arguments (1 given)
>>> 
===================== RESTART: H:/PEERS PYTHON/encap1.py =====================
>>> c1obj1.a
0
>>> c2obj1.a
1
>>> c3obj1.a
0
>>> c1obj1.m1
<bound method c1.m1 of <__main__.c1 instance at 0x0000000005D07A88>>
>>> c1obj1.m1()
0
>>> c2obj1.m1()

Traceback (most recent call last):
  File "<pyshell#5>", line 1, in <module>
    c2obj1.m1()
  File "H:/PEERS PYTHON/encap1.py", line 10, in m1
    print a
NameError: global name 'a' is not defined
>>> c2obj1.m1(1)

Traceback (most recent call last):
  File "<pyshell#6>", line 1, in <module>
    c2obj1.m1(1)
TypeError: m1() takes exactly 1 argument (2 given)
>>> c2obj1.m1()

Traceback (most recent call last):
  File "<pyshell#7>", line 1, in <module>
    c2obj1.m1()
  File "H:/PEERS PYTHON/encap1.py", line 10, in m1
    print a
NameError: global name 'a' is not defined
>>> 
===================== RESTART: H:/PEERS PYTHON/encap1.py =====================
>>> c2obj1.m1()
1
>>> c3obj1.m1(2)
2
>>> c1obj1.m1()
0
>>> c1obj1.a
0
>>> c2obj1.a
1
>>> c3obj1.a
2
>>> 
===================== RESTART: H:/PEERS PYTHON/encap1.py =====================
>>> c3obj1.m1()

Traceback (most recent call last):
  File "<pyshell#14>", line 1, in <module>
    c3obj1.m1()
TypeError: m1() takes exactly 2 arguments (1 given)
>>> c3obj1.m1(4)
>>> c3obj1.a
4
>>> 
>>> 
>>> 
>>> 

>>> 
>>> 
>>> c1obj1.a
0
>>> c2obj1.a
1
>>> c3obj1.a
4
>>> c2obj1.m1()
1
>>> c3obj1.m1(4)
>>> c1obj1.m1()
0
>>> c1obj1.a=10
>>> c2obj1.a=10
>>> c3obj1.a=10
>>> c1obj1.a
10
>>> c2obj1.a
10
>>> c3obj1.a
10
>>> 
===================== RESTART: H:/PEERS PYTHON/encap2.py =====================
>>> print c1obj1.a
100
>>> print c1obj1._b
200
>>> print c1obj1._c1_c

Traceback (most recent call last):
  File "<pyshell#37>", line 1, in <module>
    print c1obj1._c1_c
AttributeError: c1 instance has no attribute '_c1_c'
>>> print c1obj1._c1__c
300
>>> c1obj1.a=1000
>>> c1obj1._b=2000
>>> c1obj1._c1__c=3000
>>> print c1obj1.a
1000
>>> print c1obj1._b
2000
>>> print c1obj1._c1__c
3000
>>> 
>>> 
>>> 
>>> 
>>> 
===================== RESTART: H:/PEERS PYTHON/encap3.py =====================
>>> 
===================== RESTART: H:/PEERS PYTHON/encap3.py =====================
>>> c3obj1.__x

Traceback (most recent call last):
  File "<pyshell#49>", line 1, in <module>
    c3obj1.__x
AttributeError: c3 instance has no attribute '__x'
>>> c3obj1._c3__x
1000
>>> 
===================== RESTART: H:/PEERS PYTHON/encap3.py =====================
>>> c3obj3._c3__x
1000
>>> print c3obj3._c3__x
1000
>>> 
===================== RESTART: H:/PEERS PYTHON/encap3.py =====================
>>> 
===================== RESTART: H:/PEERS PYTHON/encap3.py =====================
>>> c3obj3._c3__x=150
p
>>> c3obj3._c3__x=150
>>> c3obj3._c3__x
150
>>> c3obj3.show1()
Yashu value is 150
>>> 
===================== RESTART: H:/PEERS PYTHON/encap3.py =====================
>>> c3obj3.show1()
Yashu value is 100
>>> c3obj3._c3__x
100
>>> c3obj3._c3__x=150
>>> c3obj3._c3__x
150
>>> c3obj3.show1()
Yashu value is 150
>>> 
================ RESTART: H:/PEERS PYTHON/PRIVATE_METHODP.py ================
>>> c20obj1=c20()
 this is __show2 method
>>> c20obj1.show1()
 this is show1 method 
>>> c20obj1.show2()

Traceback (most recent call last):
  File "<pyshell#64>", line 1, in <module>
    c20obj1.show2()
AttributeError: c20 instance has no attribute 'show2'
>>> c20obj1._c20__show2()
 this is __show2 method
>>> 
>>> 
>>> 
