class c9():
    def m9(self):
        return " m9 of class 9 "

class c10(c9):
    def m10(self):
        return " m10 of class 10"

class c11(c9):
    def m11(self):
        return " m11 of class 11"


c10obj1=c10()
c11obj1=c11()
c11obj1.m9()



