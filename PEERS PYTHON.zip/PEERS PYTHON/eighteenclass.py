Python 2.7.15 (v2.7.15:ca079a3ea3, Apr 30 2018, 16:30:26) [MSC v.1500 64 bit (AMD64)] on win32
Type "copyright", "credits" or "license()" for more information.
>>> 
================= RESTART: C:/Users/MY PC/Desktop/hybrid.py =================
>>> c15obj1.m12()
' m12  of class 12 '
>>> c16obj1.m12()
' m12  of class 12 '
>>> c15obj1.m14()
 m12  of class 12 
 m12 of class 13
'm14 of c14'
>>> c16obj1.m16()
' m16 of class 16'
>>> 
================ RESTART: C:/Users/MY PC/Desktop/hybridZZ.py ================
>>> c15obj1.m12()
' m12 of class 12'
>>> c16obj1.m12()
' m12 of class 12'
>>> 
================= RESTART: C:/Users/MY PC/Desktop/hybrid.py =================
>>> c15obj1.m12()
' m12  of class 12 '
>>> 
================= RESTART: C:/Users/MY PC/Desktop/hybrid.py =================
>>> c15obj1.m12()
' m12  of class 12 '
>>> 
================= RESTART: C:/Users/MY PC/Desktop/hybrid.py =================
>>> c15obj1.m12()
' m12 of class 13'
>>> 
>>> 
>>> 
>>> 
>>> 
>>>  class c2():
	def __init__(self,a,b):
		self.a=a
		self.b=b
	def __init__(self,c,d):
		self.c=c
		self.d=d
	def prnt():
		print self.a
		print self.b
		print c
		print d
		
  File "<pyshell#14>", line 2
    class c2():
    ^
IndentationError: unexpected indent
>>> class c2():
	def __init__(self,a,b):
		self.a=a
		self.b=b
	def __init__(self,c,d):
		self.c=c
		self.d=d
	def prnt():
		print self.a
		print self.b
		print c
		print d

		
>>> c2ob2=c2()

Traceback (most recent call last):
  File "<pyshell#17>", line 1, in <module>
    c2ob2=c2()
TypeError: __init__() takes exactly 3 arguments (1 given)
>>> c2ob2=c2(2,3)
>>> c2ob2.prnt()

Traceback (most recent call last):
  File "<pyshell#19>", line 1, in <module>
    c2ob2.prnt()
TypeError: prnt() takes no arguments (1 given)
>>> class c2():
	def __init__(self,a,b):
		self.a=a
		self.b=b
	def __init__(self,c,d):
		self.c=c
		self.d=d
	def prnt(self):
		print self.a
		print self.b
		print self.c
		print self.d

		
>>> ob2=c2()

Traceback (most recent call last):
  File "<pyshell#22>", line 1, in <module>
    ob2=c2()
TypeError: __init__() takes exactly 3 arguments (1 given)
>>> ob2=c2(2,3)
>>> ob2.prnt()

Traceback (most recent call last):
  File "<pyshell#24>", line 1, in <module>
    ob2.prnt()
  File "<pyshell#21>", line 9, in prnt
    print self.a
AttributeError: c2 instance has no attribute 'a'
>>> ob2.prnt()

Traceback (most recent call last):
  File "<pyshell#25>", line 1, in <module>
    ob2.prnt()
  File "<pyshell#21>", line 9, in prnt
    print self.a
AttributeError: c2 instance has no attribute 'a'
>>> class c2():
	def __init__(self,a,b):
		self.a=a
		self.b=b
	def __init__(self,c,d):
		self.c=c
		self.d=d
	def prnt(self):
		print self.a
		print self.b
		print self.c
		print self.d

	
>>> c2obj1=c2(10,20)
>>> c2obj1.prnt()

Traceback (most recent call last):
  File "<pyshell#29>", line 1, in <module>
    c2obj1.prnt()
  File "<pyshell#27>", line 9, in prnt
    print self.a
AttributeError: c2 instance has no attribute 'a'
>>> c2obj1.c
10
>>> 
>>> 
>>> 
>>> 
>>> 
