class c20():
    def __init__ (self):
        self.__show2()

    def show1(self):
        print " this is show1 method "
    def __show2(self):
        print " this is __show2 method"
"""
c20obj1=c20()
c20obj1.show1()
c20obj1.__show2() #it haS TO FAIL
"""
