import time
import multiprocessing

def printnum1(n):
    for i in range(n+1):
        time.sleep(0.3)
        print(i)
def printnum2(n):
    for i in range(n,0,-1):
        time.sleep(0.3)
        print(i)

if __name__ == "__main__":
    n=10
    p1=multiprocessing.Process(target=printnum1,args=(n,))
    p2=multiprocessing.Process(target=printnum2,args=(n,))

    p1.start()
    p2.start()

    p1.join()
    p2.join()

    print (" done ")